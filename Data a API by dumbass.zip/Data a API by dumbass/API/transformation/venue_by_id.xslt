<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="text" encoding="UTF-8"/>
    <xsl:template match="/festival">
<xsl:for-each select="stages/stage[@id='talks']">
{
  "id": "<xsl:value-of select="@id"/>",
  "type": "<xsl:value-of select="@type"/>",
  "name": "<xsl:value-of select="@name"/>"
}
</xsl:for-each>
    </xsl:template>
</xsl:stylesheet>